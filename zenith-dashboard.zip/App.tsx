import React, { useState } from 'react';
import Sidebar from './components/Sidebar';
import MainContent from './components/MainContent';
import HistoryPage from './components/history/HistoryPage';

const App: React.FC = () => {
  const [isSidebarExpanded, setIsSidebarExpanded] = useState(true);
  const [view, setView] = useState('dashboard'); // Default to 'dashboard'

  const renderView = () => {
    switch (view) {
      case 'history':
        return <HistoryPage />;
      case 'dashboard':
      case 'general':
      case 'new_thread':
        return <MainContent />;
      default:
        return <MainContent />;
    }
  };

  return (
    <div className="flex h-screen w-screen overflow-hidden font-sans text-white bg-zinc-900">
      <Sidebar 
        isExpanded={isSidebarExpanded} 
        setIsExpanded={setIsSidebarExpanded}
        view={view}
        setView={setView}
      />
      <div className="flex-1 overflow-y-auto">
        {renderView()}
      </div>
    </div>
  );
};

export default App;