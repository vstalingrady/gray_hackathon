import React from 'react';
import { LogoIcon } from './icons/LogoIcon';
import { SearchIcon } from './icons/SearchIcon';
import { HistoryIcon } from './icons/HistoryIcon';
import { ChevronLeftIcon } from './icons/ChevronLeftIcon';
import { GeneralIcon } from './icons/GeneralIcon';
import { NewThreadIcon } from './icons/NewThreadIcon';
import { DashboardIcon } from './icons/DashboardIcon';


interface SidebarProps {
  isExpanded: boolean;
  setIsExpanded: (expanded: boolean) => void;
  view: string;
  setView: (view: string) => void;
}

interface SidebarItemProps {
  icon: React.ReactNode;
  text: string;
  active?: boolean;
  isExpanded: boolean;
  onClick: () => void;
}

const SidebarItem: React.FC<SidebarItemProps> = ({ icon, text, active, isExpanded, onClick }) => {
  return (
    <li
      onClick={onClick}
      className={`
        flex items-center py-2.5 px-3 my-1 font-medium rounded-lg cursor-pointer
        transition-colors group
        ${active ? 'bg-zinc-800 text-white' : 'hover:bg-zinc-800 text-zinc-400'}
      `}
    >
      {icon}
      <span className={`overflow-hidden transition-all ${isExpanded ? 'w-40 ml-3' : 'w-0'}`}>
        {text}
      </span>
    </li>
  );
};

const Sidebar: React.FC<SidebarProps> = ({ isExpanded, setIsExpanded, view, setView }) => {
  const navItems = [
    { icon: <GeneralIcon />, text: 'General', view: 'general' },
    { icon: <NewThreadIcon />, text: 'New Thread', view: 'new_thread' },
    { icon: <DashboardIcon />, text: 'Dashboard', view: 'dashboard' },
    { icon: <HistoryIcon />, text: 'History', view: 'history' },
  ];

  const historyItems = {
    JULY: [
      'Subjective Attractiveness',
      'Comparing Decimal Numbers',
      'Mobile-Friendly Fade Effect',
      'Kill la Kill Character Moments',
      'Infinite Scrolling Payment Model',
      'Infinite Logo Scroller Implementation',
    ],
    JUNE: [
      'Chat Log Analysis Techniques',
      'Debate on Content Creation Ethics',
    ],
  };

  return (
    <aside className={`flex flex-col bg-black transition-all duration-300 ease-in-out ${isExpanded ? 'w-64' : 'w-20'}`}>
      <div className="flex items-center p-4 h-16 shrink-0 border-b border-zinc-800">
        <div className={`p-1.5 ${isExpanded ? 'mr-3' : ''}`}>
           <LogoIcon className="w-6 h-6" />
        </div>
      </div>
      
      <nav className="flex-1 px-3 py-4 overflow-y-auto">
        {/* Search Bar */}
        <div className={`flex items-center px-3 py-2 bg-zinc-900 border border-zinc-700 rounded-lg mb-4`}>
            <SearchIcon className="w-5 h-5 text-zinc-400"/>
            <span className={`overflow-hidden transition-all whitespace-nowrap ${isExpanded ? 'w-auto ml-2' : 'w-0'}`}>Search</span>
            <span className={`overflow-hidden transition-all ml-auto text-xs bg-zinc-700 text-zinc-400 px-1.5 py-0.5 rounded ${isExpanded ? 'w-auto' : 'w-0'}`}>
              Ctrl+K
            </span>
        </div>

        {/* Nav Items */}
        <ul className="flex flex-col">
          {navItems.map((item) => (
            <SidebarItem 
              key={item.text} 
              isExpanded={isExpanded}
              icon={item.icon}
              text={item.text}
              active={view === item.view}
              onClick={() => setView(item.view)} 
            />
          ))}
        </ul>

        {/* History List */}
        <div className={`mt-6 space-y-4 overflow-hidden transition-all ${isExpanded ? 'max-h-screen' : 'max-h-0'}`}>
           <div className="px-3">
               <div className="h-px bg-zinc-800"></div>
           </div>
          {Object.entries(historyItems).map(([month, items]) => (
            <div key={month}>
              <h3 className="px-3 text-xs font-semibold text-zinc-500 uppercase tracking-wider mb-2">{month}</h3>
              <ul>
                {items.map((item, index) => (
                  <li key={index} className="px-3 py-1.5 text-sm text-zinc-400 hover:text-white cursor-pointer truncate">
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </nav>

      <div className="p-3 border-t border-zinc-800">
        <div className="flex items-center">
          <img
            src="https://picsum.photos/id/433/200/200"
            alt="User Avatar"
            className="w-9 h-9 rounded-full"
          />
          <div className={`overflow-hidden transition-all flex justify-between items-center ${isExpanded ? 'w-full ml-3' : 'w-0'}`}>
              <p className="font-semibold text-sm text-white truncate">V. Stalingrady</p>
          </div>
           <button onClick={() => setIsExpanded(!isExpanded)} className="ml-auto p-2 rounded-md hover:bg-zinc-800">
              <ChevronLeftIcon className={`w-5 h-5 text-zinc-400 transition-transform duration-300 ${isExpanded ? '' : 'rotate-180'}`} />
            </button>
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;