import React from 'react';
import { SearchIcon } from '../icons/SearchIcon';

const historyData = [
    { title: "HTML/CSS History List Implementation", date: "Oct 14" },
    { title: "Subjective Attractiveness and Personal Appeal", date: "Jul 12" },
    { title: "Comparing Decimal Numbers", date: "Jul 7" },
    { title: "Mobile-Friendly Fade Effect Solutions", date: "Jul 7" },
    { title: "Kill la Kill Character Moment", date: "Jul 6" },
    { title: "Infinite Scrolling Payment Methods in React JS", date: "Jul 6" },
    { title: "Infinite Logo Scroller Implementation", date: "Jul 6" },
    { title: "Chat Log Analysis Techniques", date: "Jun 14" },
    { title: "Debate on \"Content Creator\" vs. \"Content Creation\"", date: "Jun 14" },
    { title: "Metode Titrasi Argentometri", date: "Jun 11" },
    { title: "White Hair vs. Balding: Understanding the Difference", date: "Jun 10" },
    { title: "Most Powerful UI Major for Influence", date: "Jun 3" },
    { title: "✨ Hibridisasi Orbital dalam Kimia", date: "Jun 2" },
    { title: "Jadwal SIMAK UI 2025", date: "May 30" },
    { title: "Optimism vs. Pessimism Debate", date: "May 25, 2025" },
    { title: "RTFF Usage Amid PFAS Restrictions", date: "May 21, 2025" },
];

const HistoryPage: React.FC = () => {
    return (
        <div className="flex flex-col h-full text-zinc-200 p-8 max-w-4xl mx-auto w-full">
            <header className="mb-8">
                <h1 className="text-3xl font-bold text-white">History</h1>
            </header>

            <div className="mb-8">
                <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                        <SearchIcon className="w-5 h-5 text-zinc-400" />
                    </div>
                    <input
                        type="search"
                        placeholder="Search"
                        className="w-full bg-zinc-800 border border-zinc-700 rounded-lg py-2.5 pl-11 pr-4 text-zinc-200 placeholder-zinc-400 focus:outline-none focus:ring-2 focus:ring-zinc-600"
                    />
                </div>
            </div>

            <div className="flex-1 overflow-y-auto">
                <ul>
                    {historyData.map((item, index) => (
                        <li key={index} className="flex justify-between items-center py-4 border-b border-zinc-800 hover:bg-zinc-800/50 px-2 rounded-md">
                            <span className="text-base text-zinc-200">{item.title}</span>
                            <span className="text-sm text-zinc-400 whitespace-nowrap">{item.date}</span>
                        </li>
                    ))}
                </ul>
            </div>
        </div>
    );
};

export default HistoryPage;
