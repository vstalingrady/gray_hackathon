import React from 'react';
import { BellIcon } from './icons/BellIcon';
import { CheckIcon } from './icons/CheckIcon';

const PlanItem: React.FC<{ children: React.ReactNode; checked?: boolean }> = ({ children, checked }) => (
  <div className="flex items-start space-x-3 p-3 rounded-lg hover:bg-white/5">
    <div className={`w-5 h-5 flex-shrink-0 mt-0.5 rounded flex items-center justify-center ${checked ? 'bg-blue-600' : 'border-2 border-zinc-600'}`}>
      {checked && <CheckIcon className="w-3 h-3 text-white" />}
    </div>
    <span className={`text-sm ${checked ? 'text-zinc-500 line-through' : 'text-zinc-200'}`}>{children}</span>
  </div>
);


const MainContent: React.FC = () => {
  return (
    <main className="flex-1 flex flex-col p-8 overflow-y-auto">
      {/* Header */}
      <header className="flex items-center justify-between">
        <div className="text-left">
          <h1 className="text-5xl font-bold tracking-tighter">13:17</h1>
        </div>
        <div className="text-right">
          <p className="font-semibold text-zinc-400 text-sm">SATURDAY, OCTOBER 25</p>
        </div>
        <div className="flex items-center space-x-4">
          <div className="relative">
            <BellIcon className="w-6 h-6 text-zinc-400" />
            <span className="absolute -top-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-orange-500 text-xs font-bold text-white">
              12
            </span>
          </div>
          <div className="w-10 h-10 rounded-full bg-zinc-800 flex items-center justify-center font-bold text-zinc-300">
            N
          </div>
        </div>
      </header>

      {/* Greeting */}
      <div className="text-center my-16">
        <h2 className="text-4xl font-medium text-zinc-200">Good afternoon, Vstalin Grady</h2>
      </div>

      {/* Widgets */}
      <div className="flex-1 grid grid-cols-1 lg:grid-cols-2 gap-8 items-start">
        {/* Calendar */}
        <div className="bg-black/50 p-6 rounded-2xl border border-zinc-800 h-[500px] flex flex-col">
           <h3 className="text-sm font-semibold text-zinc-400 uppercase tracking-wider mb-4">Calendar</h3>
           <div className="flex-1 overflow-y-auto pr-2">
             <div className="space-y-2">
               {Array.from({ length: 12 }).map((_, i) => (
                 <div key={i} className="flex border-b border-zinc-800 py-3">
                   <span className="w-20 text-xs text-zinc-500">{i + 12 > 12 ? `${i} AM` : '12 AM'}</span>
                   <div className="flex-1"></div>
                 </div>
               ))}
             </div>
           </div>
        </div>

        {/* Plans */}
        <div className="bg-black/50 p-6 rounded-2xl border border-zinc-800 h-[500px] flex flex-col">
          <div className="flex space-x-6 border-b border-zinc-800 mb-4">
            <button className="py-2 text-sm font-semibold text-white border-b-2 border-white">PLANS</button>
            <button className="py-2 text-sm font-semibold text-zinc-500">HABITS</button>
          </div>
          <div className="flex-1 overflow-y-auto">
            <h4 className="text-xs font-semibold uppercase text-zinc-500 tracking-wider mb-2">Plans</h4>
            <div className="space-y-1">
              <PlanItem>Restore proactive cadence for the builder cohort.</PlanItem>
              <PlanItem>Draft mitigation follow-up checklist.</PlanItem>
              <PlanItem checked>Lock launch checklist scope for the revamp.</PlanItem>
              <PlanItem>Draft async sync for builder cohort.</PlanItem>
            </div>
            <button className="mt-4 w-full text-center py-2 text-sm font-semibold text-zinc-300 bg-zinc-800 rounded-lg hover:bg-zinc-700">
                ADD PLANS
            </button>
          </div>
        </div>
      </div>
      
      {/* Ask Input */}
      <div className="mt-8 flex justify-center">
          <div className="w-full max-w-lg">
              <input 
                  type="text" 
                  placeholder="Ask anything" 
                  className="w-full bg-zinc-900/80 border border-zinc-700 rounded-full py-3 px-6 text-zinc-200 placeholder-zinc-500 focus:outline-none focus:ring-2 focus:ring-zinc-600"
              />
          </div>
      </div>
    </main>
  );
};

export default MainContent;
